# Tests for whatsappcloud
import pytest
from .whatsappcloud import *

class Test_Initialisation:
    def test_something(self):
        """ Something should happen when you run something() """
        assert something() == something_else

class Test_Core_Functions:
    def test_something(self):
        """ Something should happen when you run something() """
        assert something() == something_else

class Test_Edge_Cases:
    def test_something(self):
        """ Something should happen when you run something() """
        assert something() == something_else
